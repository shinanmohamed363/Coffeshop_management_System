﻿
namespace user_interface
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Guna.UI2.AnimatorNS.Animation animation3 = new Guna.UI2.AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.guna2VSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.btn_logout = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Settings = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Lasagna = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Savouries = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Pizza = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Btn_food = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_cofee = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2Transition1 = new Guna.UI2.WinForms.Guna2Transition();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.search_bar_Elipse = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2Separator10 = new Guna.UI2.WinForms.Guna2Separator();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.guna2VSeparator3 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.guna2VSeparator2 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_timer = new System.Windows.Forms.Label();
            this.mainpanel = new System.Windows.Forms.Panel();
            this.search_bar = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.btn_show = new Guna.UI2.WinForms.Guna2CircleButton();
            this.btn_hide = new Guna.UI2.WinForms.Guna2CircleButton();
            this.time = new System.Windows.Forms.Timer(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Black;
            this.guna2Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.guna2Panel1.Controls.Add(this.guna2CirclePictureBox2);
            this.guna2Panel1.Controls.Add(this.guna2Separator2);
            this.guna2Panel1.Controls.Add(this.guna2VSeparator1);
            this.guna2Panel1.Controls.Add(this.btn_show);
            this.guna2Panel1.Controls.Add(this.btn_hide);
            this.guna2Panel1.Controls.Add(this.guna2Separator1);
            this.guna2Panel1.Controls.Add(this.btn_logout);
            this.guna2Panel1.Controls.Add(this.btn_Settings);
            this.guna2Panel1.Controls.Add(this.btn_Lasagna);
            this.guna2Panel1.Controls.Add(this.btn_Savouries);
            this.guna2Panel1.Controls.Add(this.btn_Pizza);
            this.guna2Panel1.Controls.Add(this.Btn_food);
            this.guna2Panel1.Controls.Add(this.btn_cofee);
            this.guna2Transition1.SetDecoration(this.guna2Panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(204, 650);
            this.guna2Panel1.TabIndex = 1;
            // 
            // guna2Separator2
            // 
            this.guna2Transition1.SetDecoration(this.guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.guna2Separator2.Location = new System.Drawing.Point(3, 372);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(192, 15);
            this.guna2Separator2.TabIndex = 16;
            // 
            // guna2VSeparator1
            // 
            this.guna2VSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Transition1.SetDecoration(this.guna2VSeparator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2VSeparator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2VSeparator1.Location = new System.Drawing.Point(3, 126);
            this.guna2VSeparator1.Name = "guna2VSeparator1";
            this.guna2VSeparator1.Size = new System.Drawing.Size(10, 49);
            this.guna2VSeparator1.TabIndex = 4;
            // 
            // guna2Separator1
            // 
            this.guna2Transition1.SetDecoration(this.guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.guna2Separator1.Location = new System.Drawing.Point(12, 477);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(192, 15);
            this.guna2Separator1.TabIndex = 14;
            // 
            // btn_logout
            // 
            this.btn_logout.Animated = true;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.CheckedState.Parent = this.btn_logout;
            this.btn_logout.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_logout.CustomImages.Image")));
            this.btn_logout.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_logout.CustomImages.Parent = this.btn_logout;
            this.guna2Transition1.SetDecoration(this.btn_logout, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_logout.FillColor = System.Drawing.Color.Empty;
            this.btn_logout.FillColor2 = System.Drawing.Color.Empty;
            this.btn_logout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_logout.ForeColor = System.Drawing.Color.White;
            this.btn_logout.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_logout.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_logout.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_logout.HoverState.Parent = this.btn_logout;
            this.btn_logout.Location = new System.Drawing.Point(3, 510);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.ShadowDecoration.Parent = this.btn_logout;
            this.btn_logout.Size = new System.Drawing.Size(195, 45);
            this.btn_logout.TabIndex = 13;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseTransparentBackground = true;
            // 
            // btn_Settings
            // 
            this.btn_Settings.Animated = true;
            this.btn_Settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_Settings.CheckedState.Parent = this.btn_Settings;
            this.btn_Settings.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Settings.CustomImages.Image")));
            this.btn_Settings.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Settings.CustomImages.Parent = this.btn_Settings;
            this.guna2Transition1.SetDecoration(this.btn_Settings, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Settings.FillColor = System.Drawing.Color.Empty;
            this.btn_Settings.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Settings.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Settings.ForeColor = System.Drawing.Color.White;
            this.btn_Settings.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Settings.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Settings.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Settings.HoverState.Parent = this.btn_Settings;
            this.btn_Settings.Location = new System.Drawing.Point(0, 404);
            this.btn_Settings.Name = "btn_Settings";
            this.btn_Settings.ShadowDecoration.Parent = this.btn_Settings;
            this.btn_Settings.Size = new System.Drawing.Size(195, 45);
            this.btn_Settings.TabIndex = 12;
            this.btn_Settings.Text = "Settings";
            this.btn_Settings.UseTransparentBackground = true;
            this.btn_Settings.Click += new System.EventHandler(this.btn_Settings_Click);
            // 
            // btn_Lasagna
            // 
            this.btn_Lasagna.Animated = true;
            this.btn_Lasagna.BackColor = System.Drawing.Color.Transparent;
            this.btn_Lasagna.CheckedState.Parent = this.btn_Lasagna;
            this.btn_Lasagna.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Lasagna.CustomImages.Image")));
            this.btn_Lasagna.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Lasagna.CustomImages.Parent = this.btn_Lasagna;
            this.guna2Transition1.SetDecoration(this.btn_Lasagna, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Lasagna.FillColor = System.Drawing.Color.Empty;
            this.btn_Lasagna.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Lasagna.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Lasagna.ForeColor = System.Drawing.Color.White;
            this.btn_Lasagna.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Lasagna.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Lasagna.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Lasagna.HoverState.Parent = this.btn_Lasagna;
            this.btn_Lasagna.Location = new System.Drawing.Point(0, 321);
            this.btn_Lasagna.Name = "btn_Lasagna";
            this.btn_Lasagna.ShadowDecoration.Parent = this.btn_Lasagna;
            this.btn_Lasagna.Size = new System.Drawing.Size(195, 45);
            this.btn_Lasagna.TabIndex = 11;
            this.btn_Lasagna.Text = "Lasagna";
            this.btn_Lasagna.UseTransparentBackground = true;
            this.btn_Lasagna.Click += new System.EventHandler(this.btn_Lasagna_Click);
            // 
            // btn_Savouries
            // 
            this.btn_Savouries.Animated = true;
            this.btn_Savouries.BackColor = System.Drawing.Color.Transparent;
            this.btn_Savouries.CheckedState.Parent = this.btn_Savouries;
            this.btn_Savouries.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Savouries.CustomImages.Image")));
            this.btn_Savouries.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Savouries.CustomImages.Parent = this.btn_Savouries;
            this.guna2Transition1.SetDecoration(this.btn_Savouries, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Savouries.FillColor = System.Drawing.Color.Empty;
            this.btn_Savouries.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Savouries.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Savouries.ForeColor = System.Drawing.Color.White;
            this.btn_Savouries.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Savouries.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Savouries.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Savouries.HoverState.Parent = this.btn_Savouries;
            this.btn_Savouries.Location = new System.Drawing.Point(3, 270);
            this.btn_Savouries.Name = "btn_Savouries";
            this.btn_Savouries.ShadowDecoration.Parent = this.btn_Savouries;
            this.btn_Savouries.Size = new System.Drawing.Size(195, 45);
            this.btn_Savouries.TabIndex = 9;
            this.btn_Savouries.Text = "Savouries";
            this.btn_Savouries.UseTransparentBackground = true;
            this.btn_Savouries.Click += new System.EventHandler(this.btn_Savouries_Click);
            // 
            // btn_Pizza
            // 
            this.btn_Pizza.Animated = true;
            this.btn_Pizza.BackColor = System.Drawing.Color.Transparent;
            this.btn_Pizza.CheckedState.Parent = this.btn_Pizza;
            this.btn_Pizza.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Pizza.CustomImages.Image")));
            this.btn_Pizza.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Pizza.CustomImages.Parent = this.btn_Pizza;
            this.guna2Transition1.SetDecoration(this.btn_Pizza, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Pizza.FillColor = System.Drawing.Color.Empty;
            this.btn_Pizza.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Pizza.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Pizza.ForeColor = System.Drawing.Color.White;
            this.btn_Pizza.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Pizza.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Pizza.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Pizza.HoverState.Parent = this.btn_Pizza;
            this.btn_Pizza.Location = new System.Drawing.Point(0, 219);
            this.btn_Pizza.Name = "btn_Pizza";
            this.btn_Pizza.ShadowDecoration.Parent = this.btn_Pizza;
            this.btn_Pizza.Size = new System.Drawing.Size(195, 45);
            this.btn_Pizza.TabIndex = 8;
            this.btn_Pizza.Text = "Pizza";
            this.btn_Pizza.UseTransparentBackground = true;
            this.btn_Pizza.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // Btn_food
            // 
            this.Btn_food.Animated = true;
            this.Btn_food.BackColor = System.Drawing.Color.Transparent;
            this.Btn_food.CheckedState.Parent = this.Btn_food;
            this.Btn_food.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("Btn_food.CustomImages.Image")));
            this.Btn_food.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Btn_food.CustomImages.Parent = this.Btn_food;
            this.guna2Transition1.SetDecoration(this.Btn_food, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Btn_food.FillColor = System.Drawing.Color.Empty;
            this.Btn_food.FillColor2 = System.Drawing.Color.Empty;
            this.Btn_food.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Btn_food.ForeColor = System.Drawing.Color.White;
            this.Btn_food.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.Btn_food.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.Btn_food.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.Btn_food.HoverState.Parent = this.Btn_food;
            this.Btn_food.Location = new System.Drawing.Point(-2, 181);
            this.Btn_food.Name = "Btn_food";
            this.Btn_food.ShadowDecoration.Parent = this.Btn_food;
            this.Btn_food.Size = new System.Drawing.Size(195, 45);
            this.Btn_food.TabIndex = 7;
            this.Btn_food.Text = "Food Items";
            this.Btn_food.UseTransparentBackground = true;
            this.Btn_food.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_cofee
            // 
            this.btn_cofee.Animated = true;
            this.btn_cofee.BackColor = System.Drawing.Color.Transparent;
            this.btn_cofee.CheckedState.Parent = this.btn_cofee;
            this.btn_cofee.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_transection.CustomImages.Image")));
            this.btn_cofee.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_cofee.CustomImages.Parent = this.btn_cofee;
            this.guna2Transition1.SetDecoration(this.btn_cofee, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_cofee.FillColor = System.Drawing.Color.Empty;
            this.btn_cofee.FillColor2 = System.Drawing.Color.Empty;
            this.btn_cofee.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_cofee.ForeColor = System.Drawing.Color.White;
            this.btn_cofee.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_cofee.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_cofee.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cofee.HoverState.Parent = this.btn_cofee;
            this.btn_cofee.Location = new System.Drawing.Point(3, 130);
            this.btn_cofee.Name = "btn_cofee";
            this.btn_cofee.ShadowDecoration.Parent = this.btn_cofee;
            this.btn_cofee.Size = new System.Drawing.Size(195, 45);
            this.btn_cofee.TabIndex = 6;
            this.btn_cofee.Text = "Coffee";
            this.btn_cofee.UseTransparentBackground = true;
            this.btn_cofee.Click += new System.EventHandler(this.btn_cofee_Click);
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Controls.Add(this.search_bar);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2CirclePictureBox1);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2ControlBox1);
            this.guna2Transition1.SetDecoration(this.guna2CustomGradientPanel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CustomGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(204, 0);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.ShadowDecoration.Parent = this.guna2CustomGradientPanel1;
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(1015, 79);
            this.guna2CustomGradientPanel1.TabIndex = 12;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(86)))), ((int)(((byte)(53)))));
            this.guna2Transition1.SetDecoration(this.guna2ControlBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.Location = new System.Drawing.Point(966, 12);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(37, 26);
            this.guna2ControlBox1.TabIndex = 1;
            // 
            // guna2Transition1
            // 
            this.guna2Transition1.AnimationType = Guna.UI2.AnimatorNS.AnimationType.Rotate;
            this.guna2Transition1.Cursor = null;
            animation3.AnimateOnlyDifferences = true;
            animation3.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.BlindCoeff")));
            animation3.LeafCoeff = 0F;
            animation3.MaxTime = 1F;
            animation3.MinTime = 0F;
            animation3.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicCoeff")));
            animation3.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicShift")));
            animation3.MosaicSize = 0;
            animation3.Padding = new System.Windows.Forms.Padding(50);
            animation3.RotateCoeff = 1F;
            animation3.RotateLimit = 0F;
            animation3.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.ScaleCoeff")));
            animation3.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.SlideCoeff")));
            animation3.TimeCoeff = 0F;
            animation3.TransparencyCoeff = 1F;
            this.guna2Transition1.DefaultAnimation = animation3;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 10;
            this.guna2Elipse1.TargetControl = this;
            // 
            // search_bar_Elipse
            // 
            this.search_bar_Elipse.BorderRadius = 15;
            this.search_bar_Elipse.TargetControl = this.search_bar;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.guna2Separator10);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.guna2VSeparator3);
            this.panel1.Controls.Add(this.guna2VSeparator2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.guna2Transition1.SetDecoration(this.panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(949, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(270, 571);
            this.panel1.TabIndex = 32;
            // 
            // guna2Separator10
            // 
            this.guna2Transition1.SetDecoration(this.guna2Separator10, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator10.Location = new System.Drawing.Point(109, 316);
            this.guna2Separator10.Name = "guna2Separator10";
            this.guna2Separator10.Size = new System.Drawing.Size(157, 10);
            this.guna2Separator10.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.label5, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label5.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(219, 334);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 25);
            this.label5.TabIndex = 38;
            this.label5.Text = "0.00";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.label6, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(80, 334);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 25);
            this.label6.TabIndex = 37;
            this.label6.Text = "Total Balance";
            // 
            // guna2VSeparator3
            // 
            this.guna2Transition1.SetDecoration(this.guna2VSeparator3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2VSeparator3.Location = new System.Drawing.Point(201, 120);
            this.guna2VSeparator3.Name = "guna2VSeparator3";
            this.guna2VSeparator3.Size = new System.Drawing.Size(14, 178);
            this.guna2VSeparator3.TabIndex = 36;
            // 
            // guna2VSeparator2
            // 
            this.guna2Transition1.SetDecoration(this.guna2VSeparator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2VSeparator2.Location = new System.Drawing.Point(155, 120);
            this.guna2VSeparator2.Name = "guna2VSeparator2";
            this.guna2VSeparator2.Size = new System.Drawing.Size(10, 178);
            this.guna2VSeparator2.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.label4, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(207, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 15);
            this.label4.TabIndex = 34;
            this.label4.Text = "Total";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.label3, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(162, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 15);
            this.label3.TabIndex = 33;
            this.label3.Text = "Price";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.label1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(129, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 32;
            this.label1.Text = "Qty";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.label2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.label2.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 37);
            this.label2.TabIndex = 40;
            this.label2.Text = "Item List";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txt_timer);
            this.guna2Transition1.SetDecoration(this.panel2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 503);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(270, 68);
            this.panel2.TabIndex = 41;
            // 
            // txt_timer
            // 
            this.txt_timer.AutoSize = true;
            this.guna2Transition1.SetDecoration(this.txt_timer, Guna.UI2.AnimatorNS.DecorationType.None);
            this.txt_timer.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold);
            this.txt_timer.ForeColor = System.Drawing.Color.White;
            this.txt_timer.Location = new System.Drawing.Point(44, 11);
            this.txt_timer.Name = "txt_timer";
            this.txt_timer.Size = new System.Drawing.Size(183, 54);
            this.txt_timer.TabIndex = 42;
            this.txt_timer.Text = "00.00.00";
            this.txt_timer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mainpanel
            // 
            this.mainpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2Transition1.SetDecoration(this.mainpanel, Guna.UI2.AnimatorNS.DecorationType.None);
            this.mainpanel.Location = new System.Drawing.Point(204, 79);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(742, 568);
            this.mainpanel.TabIndex = 33;
            // 
            // search_bar
            // 
            this.search_bar.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dot;
            this.search_bar.BorderThickness = 0;
            this.search_bar.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2Transition1.SetDecoration(this.search_bar, Guna.UI2.AnimatorNS.DecorationType.None);
            this.search_bar.DefaultText = "";
            this.search_bar.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.search_bar.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.search_bar.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.search_bar.DisabledState.Parent = this.search_bar;
            this.search_bar.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.search_bar.FillColor = System.Drawing.Color.Transparent;
            this.search_bar.FocusedState.Parent = this.search_bar;
            this.search_bar.ForeColor = System.Drawing.Color.White;
            this.search_bar.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.search_bar.HoverState.Parent = this.search_bar;
            this.search_bar.IconLeft = ((System.Drawing.Image)(resources.GetObject("search_bar.IconLeft")));
            this.search_bar.Location = new System.Drawing.Point(173, 27);
            this.search_bar.Name = "search_bar";
            this.search_bar.PasswordChar = '\0';
            this.search_bar.PlaceholderText = "";
            this.search_bar.SelectedText = "";
            this.search_bar.ShadowDecoration.Parent = this.search_bar;
            this.search_bar.Size = new System.Drawing.Size(478, 31);
            this.search_bar.TabIndex = 18;
            this.search_bar.TextChanged += new System.EventHandler(this.search_bar_TextChanged);
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Transition1.SetDecoration(this.guna2CirclePictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(66, 9);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(64, 64);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.guna2CirclePictureBox1.TabIndex = 17;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2CirclePictureBox2
            // 
            this.guna2Transition1.SetDecoration(this.guna2CirclePictureBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox2.Image")));
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(45, 9);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.ShadowDecoration.Parent = this.guna2CirclePictureBox2;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(111, 115);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox2.TabIndex = 17;
            this.guna2CirclePictureBox2.TabStop = false;
            // 
            // btn_show
            // 
            this.btn_show.Animated = true;
            this.btn_show.BorderColor = System.Drawing.Color.Transparent;
            this.btn_show.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_show.CheckedState.Parent = this.btn_show;
            this.btn_show.CustomImages.Parent = this.btn_show;
            this.guna2Transition1.SetDecoration(this.btn_show, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_show.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.btn_show.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_show.ForeColor = System.Drawing.Color.White;
            this.btn_show.HoverState.Parent = this.btn_show;
            this.btn_show.Image = ((System.Drawing.Image)(resources.GetObject("btn_show.Image")));
            this.btn_show.Location = new System.Drawing.Point(6, 464);
            this.btn_show.Name = "btn_show";
            this.btn_show.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btn_show.ShadowDecoration.Parent = this.btn_show;
            this.btn_show.Size = new System.Drawing.Size(40, 40);
            this.btn_show.TabIndex = 15;
            this.btn_show.Visible = false;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.Animated = true;
            this.btn_hide.BorderColor = System.Drawing.Color.Transparent;
            this.btn_hide.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_hide.CheckedState.Parent = this.btn_hide;
            this.btn_hide.CustomImages.Parent = this.btn_hide;
            this.guna2Transition1.SetDecoration(this.btn_hide, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_hide.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.btn_hide.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_hide.ForeColor = System.Drawing.Color.White;
            this.btn_hide.HoverState.Parent = this.btn_hide;
            this.btn_hide.Image = ((System.Drawing.Image)(resources.GetObject("btn_hide.Image")));
            this.btn_hide.Location = new System.Drawing.Point(179, 464);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btn_hide.ShadowDecoration.Parent = this.btn_hide;
            this.btn_hide.Size = new System.Drawing.Size(40, 40);
            this.btn_hide.TabIndex = 2;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // time
            // 
            this.time.Enabled = true;
            this.time.Tick += new System.EventHandler(this.time_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(63)))), ((int)(((byte)(24)))));
            this.ClientSize = new System.Drawing.Size(1219, 650);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2Panel1);
            this.guna2Transition1.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.guna2CustomGradientPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2VSeparator guna2VSeparator1;
        private Guna.UI2.WinForms.Guna2CircleButton btn_show;
        private Guna.UI2.WinForms.Guna2CircleButton btn_hide;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2GradientButton btn_logout;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Settings;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Lasagna;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Savouries;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Pizza;
        private Guna.UI2.WinForms.Guna2GradientButton Btn_food;
        private Guna.UI2.WinForms.Guna2GradientButton btn_cofee;
        private Guna.UI2.WinForms.Guna2Transition guna2Transition1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse search_bar_Elipse;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private Guna.UI2.WinForms.Guna2TextBox search_bar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label txt_timer;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator10;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2VSeparator guna2VSeparator3;
        private Guna.UI2.WinForms.Guna2VSeparator guna2VSeparator2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.Timer time;
    }
}

