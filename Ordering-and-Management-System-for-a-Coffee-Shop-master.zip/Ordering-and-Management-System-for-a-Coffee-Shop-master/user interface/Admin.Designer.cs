﻿
namespace user_interface
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Guna.UI2.AnimatorNS.Animation animation1 = new Guna.UI2.AnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.dSales_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.addItems_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.guna2VSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.btn_show = new Guna.UI2.WinForms.Guna2CircleButton();
            this.btn_hide = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.btn_logout = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Settings = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_ChangePW = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_addEmployee = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.cancle = new Guna.UI2.WinForms.Guna2GradientButton();
            this.txt_timer = new System.Windows.Forms.Label();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.adminTransition = new Guna.UI2.WinForms.Guna2Transition();
            this.adminMain_pnl = new System.Windows.Forms.Panel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.cancleElipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.guna2CustomGradientPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Black;
            this.guna2Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.guna2Panel1.Controls.Add(this.guna2GradientButton1);
            this.guna2Panel1.Controls.Add(this.dSales_btn);
            this.guna2Panel1.Controls.Add(this.addItems_btn);
            this.guna2Panel1.Controls.Add(this.guna2CirclePictureBox2);
            this.guna2Panel1.Controls.Add(this.guna2Separator2);
            this.guna2Panel1.Controls.Add(this.guna2VSeparator1);
            this.guna2Panel1.Controls.Add(this.btn_show);
            this.guna2Panel1.Controls.Add(this.btn_hide);
            this.guna2Panel1.Controls.Add(this.guna2Separator1);
            this.guna2Panel1.Controls.Add(this.btn_logout);
            this.guna2Panel1.Controls.Add(this.btn_Settings);
            this.guna2Panel1.Controls.Add(this.btn_ChangePW);
            this.guna2Panel1.Controls.Add(this.btn_addEmployee);
            this.adminTransition.SetDecoration(this.guna2Panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(204, 656);
            this.guna2Panel1.TabIndex = 2;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Animated = true;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.adminTransition.SetDecoration(this.guna2GradientButton1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton1.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton1.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(0, 232);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(195, 45);
            this.guna2GradientButton1.TabIndex = 20;
            this.guna2GradientButton1.Text = "Report";
            this.guna2GradientButton1.UseTransparentBackground = true;
            // 
            // dSales_btn
            // 
            this.dSales_btn.Animated = true;
            this.dSales_btn.BackColor = System.Drawing.Color.Transparent;
            this.dSales_btn.CheckedState.Parent = this.dSales_btn;
            this.dSales_btn.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.dSales_btn.CustomImages.Parent = this.dSales_btn;
            this.adminTransition.SetDecoration(this.dSales_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.dSales_btn.FillColor = System.Drawing.Color.Empty;
            this.dSales_btn.FillColor2 = System.Drawing.Color.Empty;
            this.dSales_btn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dSales_btn.ForeColor = System.Drawing.Color.White;
            this.dSales_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.dSales_btn.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.dSales_btn.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.dSales_btn.HoverState.Parent = this.dSales_btn;
            this.dSales_btn.Location = new System.Drawing.Point(6, 181);
            this.dSales_btn.Name = "dSales_btn";
            this.dSales_btn.ShadowDecoration.Parent = this.dSales_btn;
            this.dSales_btn.Size = new System.Drawing.Size(195, 45);
            this.dSales_btn.TabIndex = 19;
            this.dSales_btn.Text = "Daily Sales";
            this.dSales_btn.UseTransparentBackground = true;
            this.dSales_btn.Click += new System.EventHandler(this.dSales_btn_Click);
            // 
            // addItems_btn
            // 
            this.addItems_btn.Animated = true;
            this.addItems_btn.BackColor = System.Drawing.Color.Transparent;
            this.addItems_btn.CheckedState.Parent = this.addItems_btn;
            this.addItems_btn.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.addItems_btn.CustomImages.Parent = this.addItems_btn;
            this.adminTransition.SetDecoration(this.addItems_btn, Guna.UI2.AnimatorNS.DecorationType.None);
            this.addItems_btn.FillColor = System.Drawing.Color.Empty;
            this.addItems_btn.FillColor2 = System.Drawing.Color.Empty;
            this.addItems_btn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.addItems_btn.ForeColor = System.Drawing.Color.White;
            this.addItems_btn.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.addItems_btn.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.addItems_btn.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.addItems_btn.HoverState.Parent = this.addItems_btn;
            this.addItems_btn.Location = new System.Drawing.Point(3, 130);
            this.addItems_btn.Name = "addItems_btn";
            this.addItems_btn.ShadowDecoration.Parent = this.addItems_btn;
            this.addItems_btn.Size = new System.Drawing.Size(195, 45);
            this.addItems_btn.TabIndex = 18;
            this.addItems_btn.Text = "Add Items";
            this.addItems_btn.UseTransparentBackground = true;
            this.addItems_btn.Click += new System.EventHandler(this.addItems_btn_Click);
            // 
            // guna2CirclePictureBox2
            // 
            this.adminTransition.SetDecoration(this.guna2CirclePictureBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox2.Image")));
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(42, 3);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.ShadowDecoration.Parent = this.guna2CirclePictureBox2;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(111, 115);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox2.TabIndex = 17;
            this.guna2CirclePictureBox2.TabStop = false;
            // 
            // guna2Separator2
            // 
            this.adminTransition.SetDecoration(this.guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.guna2Separator2.Location = new System.Drawing.Point(3, 372);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(192, 15);
            this.guna2Separator2.TabIndex = 16;
            // 
            // guna2VSeparator1
            // 
            this.guna2VSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.adminTransition.SetDecoration(this.guna2VSeparator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2VSeparator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2VSeparator1.Location = new System.Drawing.Point(3, 126);
            this.guna2VSeparator1.Name = "guna2VSeparator1";
            this.guna2VSeparator1.Size = new System.Drawing.Size(10, 49);
            this.guna2VSeparator1.TabIndex = 4;
            // 
            // btn_show
            // 
            this.btn_show.Animated = true;
            this.btn_show.BorderColor = System.Drawing.Color.Transparent;
            this.btn_show.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_show.CheckedState.Parent = this.btn_show;
            this.btn_show.CustomImages.Parent = this.btn_show;
            this.adminTransition.SetDecoration(this.btn_show, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_show.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.btn_show.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_show.ForeColor = System.Drawing.Color.White;
            this.btn_show.HoverState.Parent = this.btn_show;
            this.btn_show.Image = ((System.Drawing.Image)(resources.GetObject("btn_show.Image")));
            this.btn_show.Location = new System.Drawing.Point(6, 464);
            this.btn_show.Name = "btn_show";
            this.btn_show.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btn_show.ShadowDecoration.Parent = this.btn_show;
            this.btn_show.Size = new System.Drawing.Size(40, 40);
            this.btn_show.TabIndex = 15;
            this.btn_show.Visible = false;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.Animated = true;
            this.btn_hide.BorderColor = System.Drawing.Color.Transparent;
            this.btn_hide.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_hide.CheckedState.Parent = this.btn_hide;
            this.btn_hide.CustomImages.Parent = this.btn_hide;
            this.adminTransition.SetDecoration(this.btn_hide, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_hide.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.btn_hide.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_hide.ForeColor = System.Drawing.Color.White;
            this.btn_hide.HoverState.Parent = this.btn_hide;
            this.btn_hide.Image = ((System.Drawing.Image)(resources.GetObject("btn_hide.Image")));
            this.btn_hide.Location = new System.Drawing.Point(179, 464);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btn_hide.ShadowDecoration.Parent = this.btn_hide;
            this.btn_hide.Size = new System.Drawing.Size(40, 40);
            this.btn_hide.TabIndex = 2;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // guna2Separator1
            // 
            this.adminTransition.SetDecoration(this.guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.guna2Separator1.Location = new System.Drawing.Point(12, 477);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(192, 15);
            this.guna2Separator1.TabIndex = 14;
            // 
            // btn_logout
            // 
            this.btn_logout.Animated = true;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.CheckedState.Parent = this.btn_logout;
            this.btn_logout.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_logout.CustomImages.Image")));
            this.btn_logout.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_logout.CustomImages.Parent = this.btn_logout;
            this.adminTransition.SetDecoration(this.btn_logout, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_logout.FillColor = System.Drawing.Color.Empty;
            this.btn_logout.FillColor2 = System.Drawing.Color.Empty;
            this.btn_logout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_logout.ForeColor = System.Drawing.Color.White;
            this.btn_logout.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_logout.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_logout.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_logout.HoverState.Parent = this.btn_logout;
            this.btn_logout.Location = new System.Drawing.Point(3, 510);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.ShadowDecoration.Parent = this.btn_logout;
            this.btn_logout.Size = new System.Drawing.Size(195, 45);
            this.btn_logout.TabIndex = 13;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseTransparentBackground = true;
            // 
            // btn_Settings
            // 
            this.btn_Settings.Animated = true;
            this.btn_Settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_Settings.CheckedState.Parent = this.btn_Settings;
            this.btn_Settings.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Settings.CustomImages.Image")));
            this.btn_Settings.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Settings.CustomImages.Parent = this.btn_Settings;
            this.adminTransition.SetDecoration(this.btn_Settings, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Settings.FillColor = System.Drawing.Color.Empty;
            this.btn_Settings.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Settings.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Settings.ForeColor = System.Drawing.Color.White;
            this.btn_Settings.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Settings.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Settings.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Settings.HoverState.Parent = this.btn_Settings;
            this.btn_Settings.Location = new System.Drawing.Point(0, 404);
            this.btn_Settings.Name = "btn_Settings";
            this.btn_Settings.ShadowDecoration.Parent = this.btn_Settings;
            this.btn_Settings.Size = new System.Drawing.Size(195, 45);
            this.btn_Settings.TabIndex = 12;
            this.btn_Settings.Text = "Settings";
            this.btn_Settings.UseTransparentBackground = true;
            // 
            // btn_ChangePW
            // 
            this.btn_ChangePW.Animated = true;
            this.btn_ChangePW.BackColor = System.Drawing.Color.Transparent;
            this.btn_ChangePW.CheckedState.Parent = this.btn_ChangePW;
            this.btn_ChangePW.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_ChangePW.CustomImages.Parent = this.btn_ChangePW;
            this.adminTransition.SetDecoration(this.btn_ChangePW, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_ChangePW.FillColor = System.Drawing.Color.Empty;
            this.btn_ChangePW.FillColor2 = System.Drawing.Color.Empty;
            this.btn_ChangePW.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_ChangePW.ForeColor = System.Drawing.Color.White;
            this.btn_ChangePW.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_ChangePW.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_ChangePW.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_ChangePW.HoverState.Parent = this.btn_ChangePW;
            this.btn_ChangePW.Location = new System.Drawing.Point(0, 321);
            this.btn_ChangePW.Name = "btn_ChangePW";
            this.btn_ChangePW.ShadowDecoration.Parent = this.btn_ChangePW;
            this.btn_ChangePW.Size = new System.Drawing.Size(195, 45);
            this.btn_ChangePW.TabIndex = 11;
            this.btn_ChangePW.Text = "Change Password";
            this.btn_ChangePW.UseTransparentBackground = true;
            this.btn_ChangePW.Click += new System.EventHandler(this.btn_ChangePW_Click);
            // 
            // btn_addEmployee
            // 
            this.btn_addEmployee.Animated = true;
            this.btn_addEmployee.BackColor = System.Drawing.Color.Transparent;
            this.btn_addEmployee.CheckedState.Parent = this.btn_addEmployee;
            this.btn_addEmployee.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_addEmployee.CustomImages.Parent = this.btn_addEmployee;
            this.adminTransition.SetDecoration(this.btn_addEmployee, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_addEmployee.FillColor = System.Drawing.Color.Empty;
            this.btn_addEmployee.FillColor2 = System.Drawing.Color.Empty;
            this.btn_addEmployee.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_addEmployee.ForeColor = System.Drawing.Color.White;
            this.btn_addEmployee.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_addEmployee.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_addEmployee.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_addEmployee.HoverState.Parent = this.btn_addEmployee;
            this.btn_addEmployee.Location = new System.Drawing.Point(3, 270);
            this.btn_addEmployee.Name = "btn_addEmployee";
            this.btn_addEmployee.ShadowDecoration.Parent = this.btn_addEmployee;
            this.btn_addEmployee.Size = new System.Drawing.Size(195, 45);
            this.btn_addEmployee.TabIndex = 9;
            this.btn_addEmployee.Text = "Add Employee";
            this.btn_addEmployee.UseTransparentBackground = true;
            this.btn_addEmployee.Click += new System.EventHandler(this.btn_addEmployee_Click);
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2CustomGradientPanel2);
            this.guna2CustomGradientPanel1.Controls.Add(this.txt_timer);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2CirclePictureBox1);
            this.adminTransition.SetDecoration(this.guna2CustomGradientPanel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CustomGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(204, 0);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.ShadowDecoration.Parent = this.guna2CustomGradientPanel1;
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(833, 75);
            this.guna2CustomGradientPanel1.TabIndex = 13;
            this.guna2CustomGradientPanel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.guna2CustomGradientPanel1_MouseDown);
            this.guna2CustomGradientPanel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.guna2CustomGradientPanel1_MouseMove);
            this.guna2CustomGradientPanel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.guna2CustomGradientPanel1_MouseUp);
            // 
            // guna2CustomGradientPanel2
            // 
            this.guna2CustomGradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("guna2CustomGradientPanel2.BackgroundImage")));
            this.guna2CustomGradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.guna2CustomGradientPanel2.BorderColor = System.Drawing.Color.White;
            this.guna2CustomGradientPanel2.Controls.Add(this.cancle);
            this.adminTransition.SetDecoration(this.guna2CustomGradientPanel2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CustomGradientPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.guna2CustomGradientPanel2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(63)))), ((int)(((byte)(24)))));
            this.guna2CustomGradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(63)))), ((int)(((byte)(24)))));
            this.guna2CustomGradientPanel2.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(63)))), ((int)(((byte)(24)))));
            this.guna2CustomGradientPanel2.FillColor4 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel2.Location = new System.Drawing.Point(748, 0);
            this.guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            this.guna2CustomGradientPanel2.ShadowDecoration.Parent = this.guna2CustomGradientPanel2;
            this.guna2CustomGradientPanel2.Size = new System.Drawing.Size(85, 75);
            this.guna2CustomGradientPanel2.TabIndex = 44;
            // 
            // cancle
            // 
            this.cancle.CheckedState.Parent = this.cancle;
            this.cancle.CustomImages.Parent = this.cancle;
            this.adminTransition.SetDecoration(this.cancle, Guna.UI2.AnimatorNS.DecorationType.None);
            this.cancle.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(95)))), ((int)(((byte)(56)))), ((int)(((byte)(22)))));
            this.cancle.FillColor2 = System.Drawing.Color.Black;
            this.cancle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cancle.ForeColor = System.Drawing.Color.White;
            this.cancle.HoverState.Parent = this.cancle;
            this.cancle.Image = ((System.Drawing.Image)(resources.GetObject("cancle.Image")));
            this.cancle.Location = new System.Drawing.Point(26, 9);
            this.cancle.Name = "cancle";
            this.cancle.ShadowDecoration.Parent = this.cancle;
            this.cancle.Size = new System.Drawing.Size(47, 31);
            this.cancle.TabIndex = 42;
            this.cancle.Click += new System.EventHandler(this.cancle_Click);
            // 
            // txt_timer
            // 
            this.txt_timer.AutoSize = true;
            this.txt_timer.BackColor = System.Drawing.Color.Transparent;
            this.adminTransition.SetDecoration(this.txt_timer, Guna.UI2.AnimatorNS.DecorationType.None);
            this.txt_timer.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold);
            this.txt_timer.ForeColor = System.Drawing.Color.White;
            this.txt_timer.Location = new System.Drawing.Point(19, 9);
            this.txt_timer.Name = "txt_timer";
            this.txt_timer.Size = new System.Drawing.Size(183, 54);
            this.txt_timer.TabIndex = 43;
            this.txt_timer.Text = "00.00.00";
            this.txt_timer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.adminTransition.SetDecoration(this.guna2CirclePictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(509, 3);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(64, 64);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.guna2CirclePictureBox1.TabIndex = 17;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // adminTransition
            // 
            this.adminTransition.AnimationType = Guna.UI2.AnimatorNS.AnimationType.Rotate;
            this.adminTransition.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(50);
            animation1.RotateCoeff = 1F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 1F;
            this.adminTransition.DefaultAnimation = animation1;
            // 
            // adminMain_pnl
            // 
            this.adminTransition.SetDecoration(this.adminMain_pnl, Guna.UI2.AnimatorNS.DecorationType.None);
            this.adminMain_pnl.Dock = System.Windows.Forms.DockStyle.Right;
            this.adminMain_pnl.Location = new System.Drawing.Point(201, 75);
            this.adminMain_pnl.Name = "adminMain_pnl";
            this.adminMain_pnl.Size = new System.Drawing.Size(836, 581);
            this.adminMain_pnl.TabIndex = 14;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 9;
            this.guna2Elipse1.TargetControl = this;
            // 
            // cancleElipse2
            // 
            this.cancleElipse2.TargetControl = this.cancle;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 656);
            this.Controls.Add(this.adminMain_pnl);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2Panel1);
            this.adminTransition.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin";
            this.Text = "Admin";
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.guna2CustomGradientPanel1.PerformLayout();
            this.guna2CustomGradientPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2VSeparator guna2VSeparator1;
        private Guna.UI2.WinForms.Guna2CircleButton btn_show;
        private Guna.UI2.WinForms.Guna2CircleButton btn_hide;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2GradientButton btn_logout;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Settings;
        private Guna.UI2.WinForms.Guna2GradientButton btn_ChangePW;
        private Guna.UI2.WinForms.Guna2GradientButton btn_addEmployee;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private System.Windows.Forms.Label txt_timer;
        private Guna.UI2.WinForms.Guna2Transition adminTransition;
        private System.Windows.Forms.Panel adminMain_pnl;
        private Guna.UI2.WinForms.Guna2GradientButton addItems_btn;
        private Guna.UI2.WinForms.Guna2GradientButton dSales_btn;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private Guna.UI2.WinForms.Guna2GradientButton cancle;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse cancleElipse2;
    }
}