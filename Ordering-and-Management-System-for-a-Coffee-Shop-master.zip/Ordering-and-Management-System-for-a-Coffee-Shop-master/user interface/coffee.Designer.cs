﻿
namespace user_interface
{
    partial class coffee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(coffee));
            this.coffeeform = new System.Windows.Forms.FlowLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.guna2GradientButton5 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2Separator3 = new Guna.UI2.WinForms.Guna2Separator();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2Separator4 = new Guna.UI2.WinForms.Guna2Separator();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.guna2GradientButton7 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton8 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label25 = new System.Windows.Forms.Label();
            this.guna2Separator5 = new Guna.UI2.WinForms.Guna2Separator();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.guna2GradientButton10 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton11 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.guna2GradientButton6 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label33 = new System.Windows.Forms.Label();
            this.guna2Separator6 = new Guna.UI2.WinForms.Guna2Separator();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.guna2GradientButton13 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton14 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.guna2GradientButton9 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label41 = new System.Windows.Forms.Label();
            this.guna2Separator7 = new Guna.UI2.WinForms.Guna2Separator();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.guna2GradientButton16 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton17 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.label50 = new System.Windows.Forms.Label();
            this.Cappuccino_panel = new System.Windows.Forms.Panel();
            this.tital_panal_cappuccino = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel3 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel4 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.guna2CustomGradientPanel5 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.coffeeform.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel12.SuspendLayout();
            this.Cappuccino_panel.SuspendLayout();
            this.tital_panal_cappuccino.SuspendLayout();
            this.panel7.SuspendLayout();
            this.guna2CustomGradientPanel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.guna2CustomGradientPanel3.SuspendLayout();
            this.panel11.SuspendLayout();
            this.guna2CustomGradientPanel4.SuspendLayout();
            this.panel13.SuspendLayout();
            this.guna2CustomGradientPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // coffeeform
            // 
            this.coffeeform.AutoScroll = true;
            this.coffeeform.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.coffeeform.Controls.Add(this.panel4);
            this.coffeeform.Controls.Add(this.panel6);
            this.coffeeform.Controls.Add(this.panel8);
            this.coffeeform.Controls.Add(this.panel10);
            this.coffeeform.Controls.Add(this.panel12);
            this.coffeeform.Controls.Add(this.label50);
            this.coffeeform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.coffeeform.Location = new System.Drawing.Point(0, 0);
            this.coffeeform.Margin = new System.Windows.Forms.Padding(4);
            this.coffeeform.Name = "coffeeform";
            this.coffeeform.Size = new System.Drawing.Size(1067, 554);
            this.coffeeform.TabIndex = 15;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.guna2GradientButton5);
            this.panel4.Controls.Add(this.guna2Separator3);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.guna2GradientButton4);
            this.panel4.Controls.Add(this.guna2GradientButton3);
            this.panel4.Controls.Add(this.Cappuccino_panel);
            this.panel4.Location = new System.Drawing.Point(4, 4);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(445, 672);
            this.panel4.TabIndex = 0;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(61, 619);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 23);
            this.label17.TabIndex = 22;
            this.label17.Text = "Rs 200";
            // 
            // guna2GradientButton5
            // 
            this.guna2GradientButton5.Animated = true;
            this.guna2GradientButton5.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton5.CheckedState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton5.CustomImages.Image")));
            this.guna2GradientButton5.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton5.CustomImages.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton5.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton5.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton5.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton5.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton5.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton5.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton5.HoverState.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Location = new System.Drawing.Point(205, 578);
            this.guna2GradientButton5.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton5.Name = "guna2GradientButton5";
            this.guna2GradientButton5.ShadowDecoration.Parent = this.guna2GradientButton5;
            this.guna2GradientButton5.Size = new System.Drawing.Size(188, 64);
            this.guna2GradientButton5.TabIndex = 21;
            this.guna2GradientButton5.Text = "Add to Bill";
            this.guna2GradientButton5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton5.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton5.UseTransparentBackground = true;
            // 
            // guna2Separator3
            // 
            this.guna2Separator3.Location = new System.Drawing.Point(35, 559);
            this.guna2Separator3.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Separator3.Name = "guna2Separator3";
            this.guna2Separator3.Size = new System.Drawing.Size(381, 12);
            this.guna2Separator3.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(43, 567);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 46);
            this.label15.TabIndex = 19;
            this.label15.Text = "Price";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(63, 513);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 20);
            this.label16.TabIndex = 18;
            this.label16.Text = "size";
            // 
            // guna2GradientButton4
            // 
            this.guna2GradientButton4.Animated = true;
            this.guna2GradientButton4.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton4.CheckedState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton4.CustomImages.Image")));
            this.guna2GradientButton4.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton4.CustomImages.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton4.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton4.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton4.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton4.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton4.HoverState.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Location = new System.Drawing.Point(180, 496);
            this.guna2GradientButton4.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton4.Name = "guna2GradientButton4";
            this.guna2GradientButton4.ShadowDecoration.Parent = this.guna2GradientButton4;
            this.guna2GradientButton4.Size = new System.Drawing.Size(115, 55);
            this.guna2GradientButton4.TabIndex = 17;
            this.guna2GradientButton4.Text = "Medium";
            this.guna2GradientButton4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton4.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton4.UseTransparentBackground = true;
            // 
            // guna2GradientButton3
            // 
            this.guna2GradientButton3.Animated = true;
            this.guna2GradientButton3.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton3.CheckedState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton3.CustomImages.Image")));
            this.guna2GradientButton3.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton3.CustomImages.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton3.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton3.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton3.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton3.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton3.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton3.HoverState.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Location = new System.Drawing.Point(296, 496);
            this.guna2GradientButton3.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton3.Name = "guna2GradientButton3";
            this.guna2GradientButton3.ShadowDecoration.Parent = this.guna2GradientButton3;
            this.guna2GradientButton3.Size = new System.Drawing.Size(140, 55);
            this.guna2GradientButton3.TabIndex = 16;
            this.guna2GradientButton3.Text = "Large";
            this.guna2GradientButton3.UseTransparentBackground = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.guna2GradientButton1);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.guna2Separator4);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.guna2GradientButton7);
            this.panel6.Controls.Add(this.guna2GradientButton8);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Location = new System.Drawing.Point(457, 4);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(445, 672);
            this.panel6.TabIndex = 23;
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Animated = true;
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.CheckedState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton1.CustomImages.Image")));
            this.guna2GradientButton1.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton1.CustomImages.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton1.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton1.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton1.HoverState.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Location = new System.Drawing.Point(216, 577);
            this.guna2GradientButton1.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.ShadowDecoration.Parent = this.guna2GradientButton1;
            this.guna2GradientButton1.Size = new System.Drawing.Size(188, 64);
            this.guna2GradientButton1.TabIndex = 23;
            this.guna2GradientButton1.Text = "Add to Bill";
            this.guna2GradientButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton1.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton1.UseTransparentBackground = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(61, 619);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 23);
            this.label8.TabIndex = 22;
            this.label8.Text = "Rs 200";
            // 
            // guna2Separator4
            // 
            this.guna2Separator4.Location = new System.Drawing.Point(35, 559);
            this.guna2Separator4.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Separator4.Name = "guna2Separator4";
            this.guna2Separator4.Size = new System.Drawing.Size(381, 12);
            this.guna2Separator4.TabIndex = 20;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(43, 567);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(99, 46);
            this.label18.TabIndex = 19;
            this.label18.Text = "Price";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(63, 513);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 20);
            this.label19.TabIndex = 18;
            this.label19.Text = "size";
            // 
            // guna2GradientButton7
            // 
            this.guna2GradientButton7.Animated = true;
            this.guna2GradientButton7.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton7.CheckedState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton7.CustomImages.Image")));
            this.guna2GradientButton7.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton7.CustomImages.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton7.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton7.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton7.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton7.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton7.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton7.HoverState.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Location = new System.Drawing.Point(180, 496);
            this.guna2GradientButton7.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton7.Name = "guna2GradientButton7";
            this.guna2GradientButton7.ShadowDecoration.Parent = this.guna2GradientButton7;
            this.guna2GradientButton7.Size = new System.Drawing.Size(115, 55);
            this.guna2GradientButton7.TabIndex = 17;
            this.guna2GradientButton7.Text = "Medium";
            this.guna2GradientButton7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton7.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton7.UseTransparentBackground = true;
            // 
            // guna2GradientButton8
            // 
            this.guna2GradientButton8.Animated = true;
            this.guna2GradientButton8.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton8.CheckedState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton8.CustomImages.Image")));
            this.guna2GradientButton8.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton8.CustomImages.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton8.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton8.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton8.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton8.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton8.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton8.HoverState.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Location = new System.Drawing.Point(296, 496);
            this.guna2GradientButton8.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton8.Name = "guna2GradientButton8";
            this.guna2GradientButton8.ShadowDecoration.Parent = this.guna2GradientButton8;
            this.guna2GradientButton8.Size = new System.Drawing.Size(140, 55);
            this.guna2GradientButton8.TabIndex = 16;
            this.guna2GradientButton8.Text = "Large";
            this.guna2GradientButton8.UseTransparentBackground = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.guna2GradientButton2);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.guna2Separator5);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.label27);
            this.panel8.Controls.Add(this.guna2GradientButton10);
            this.panel8.Controls.Add(this.guna2GradientButton11);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Location = new System.Drawing.Point(4, 684);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(445, 672);
            this.panel8.TabIndex = 24;
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.Animated = true;
            this.guna2GradientButton2.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.CheckedState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton2.CustomImages.Image")));
            this.guna2GradientButton2.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton2.CustomImages.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton2.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton2.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton2.HoverState.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Location = new System.Drawing.Point(212, 575);
            this.guna2GradientButton2.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.ShadowDecoration.Parent = this.guna2GradientButton2;
            this.guna2GradientButton2.Size = new System.Drawing.Size(188, 64);
            this.guna2GradientButton2.TabIndex = 23;
            this.guna2GradientButton2.Text = "Add to Bill";
            this.guna2GradientButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton2.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton2.UseTransparentBackground = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(61, 619);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(63, 23);
            this.label25.TabIndex = 22;
            this.label25.Text = "Rs 200";
            // 
            // guna2Separator5
            // 
            this.guna2Separator5.Location = new System.Drawing.Point(35, 559);
            this.guna2Separator5.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Separator5.Name = "guna2Separator5";
            this.guna2Separator5.Size = new System.Drawing.Size(381, 12);
            this.guna2Separator5.TabIndex = 20;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(43, 567);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 46);
            this.label26.TabIndex = 19;
            this.label26.Text = "Price";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(63, 513);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(35, 20);
            this.label27.TabIndex = 18;
            this.label27.Text = "size";
            // 
            // guna2GradientButton10
            // 
            this.guna2GradientButton10.Animated = true;
            this.guna2GradientButton10.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton10.CheckedState.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton10.CustomImages.Image")));
            this.guna2GradientButton10.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton10.CustomImages.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton10.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton10.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton10.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton10.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton10.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton10.HoverState.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Location = new System.Drawing.Point(180, 496);
            this.guna2GradientButton10.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton10.Name = "guna2GradientButton10";
            this.guna2GradientButton10.ShadowDecoration.Parent = this.guna2GradientButton10;
            this.guna2GradientButton10.Size = new System.Drawing.Size(115, 55);
            this.guna2GradientButton10.TabIndex = 17;
            this.guna2GradientButton10.Text = "Medium";
            this.guna2GradientButton10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton10.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton10.UseTransparentBackground = true;
            // 
            // guna2GradientButton11
            // 
            this.guna2GradientButton11.Animated = true;
            this.guna2GradientButton11.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton11.CheckedState.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton11.CustomImages.Image")));
            this.guna2GradientButton11.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton11.CustomImages.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton11.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton11.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton11.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton11.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton11.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton11.HoverState.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Location = new System.Drawing.Point(296, 496);
            this.guna2GradientButton11.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton11.Name = "guna2GradientButton11";
            this.guna2GradientButton11.ShadowDecoration.Parent = this.guna2GradientButton11;
            this.guna2GradientButton11.Size = new System.Drawing.Size(140, 55);
            this.guna2GradientButton11.TabIndex = 16;
            this.guna2GradientButton11.Text = "Large";
            this.guna2GradientButton11.UseTransparentBackground = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.guna2GradientButton6);
            this.panel10.Controls.Add(this.label33);
            this.panel10.Controls.Add(this.guna2Separator6);
            this.panel10.Controls.Add(this.label34);
            this.panel10.Controls.Add(this.label35);
            this.panel10.Controls.Add(this.guna2GradientButton13);
            this.panel10.Controls.Add(this.guna2GradientButton14);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Location = new System.Drawing.Point(457, 684);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(445, 672);
            this.panel10.TabIndex = 25;
            // 
            // guna2GradientButton6
            // 
            this.guna2GradientButton6.Animated = true;
            this.guna2GradientButton6.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton6.CheckedState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton6.CustomImages.Image")));
            this.guna2GradientButton6.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton6.CustomImages.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton6.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton6.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton6.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton6.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton6.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton6.HoverState.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Location = new System.Drawing.Point(203, 575);
            this.guna2GradientButton6.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton6.Name = "guna2GradientButton6";
            this.guna2GradientButton6.ShadowDecoration.Parent = this.guna2GradientButton6;
            this.guna2GradientButton6.Size = new System.Drawing.Size(188, 64);
            this.guna2GradientButton6.TabIndex = 23;
            this.guna2GradientButton6.Text = "Add to Bill";
            this.guna2GradientButton6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton6.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton6.UseTransparentBackground = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(61, 619);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(63, 23);
            this.label33.TabIndex = 22;
            this.label33.Text = "Rs 200";
            // 
            // guna2Separator6
            // 
            this.guna2Separator6.Location = new System.Drawing.Point(35, 559);
            this.guna2Separator6.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Separator6.Name = "guna2Separator6";
            this.guna2Separator6.Size = new System.Drawing.Size(381, 12);
            this.guna2Separator6.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(43, 567);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(99, 46);
            this.label34.TabIndex = 19;
            this.label34.Text = "Price";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(63, 513);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(35, 20);
            this.label35.TabIndex = 18;
            this.label35.Text = "size";
            // 
            // guna2GradientButton13
            // 
            this.guna2GradientButton13.Animated = true;
            this.guna2GradientButton13.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton13.CheckedState.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton13.CustomImages.Image")));
            this.guna2GradientButton13.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton13.CustomImages.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton13.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton13.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton13.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton13.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton13.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton13.HoverState.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Location = new System.Drawing.Point(180, 496);
            this.guna2GradientButton13.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton13.Name = "guna2GradientButton13";
            this.guna2GradientButton13.ShadowDecoration.Parent = this.guna2GradientButton13;
            this.guna2GradientButton13.Size = new System.Drawing.Size(115, 55);
            this.guna2GradientButton13.TabIndex = 17;
            this.guna2GradientButton13.Text = "Medium";
            this.guna2GradientButton13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton13.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton13.UseTransparentBackground = true;
            // 
            // guna2GradientButton14
            // 
            this.guna2GradientButton14.Animated = true;
            this.guna2GradientButton14.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton14.CheckedState.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton14.CustomImages.Image")));
            this.guna2GradientButton14.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton14.CustomImages.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton14.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton14.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton14.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton14.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton14.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton14.HoverState.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Location = new System.Drawing.Point(296, 496);
            this.guna2GradientButton14.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton14.Name = "guna2GradientButton14";
            this.guna2GradientButton14.ShadowDecoration.Parent = this.guna2GradientButton14;
            this.guna2GradientButton14.Size = new System.Drawing.Size(140, 55);
            this.guna2GradientButton14.TabIndex = 16;
            this.guna2GradientButton14.Text = "Large";
            this.guna2GradientButton14.UseTransparentBackground = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.guna2GradientButton9);
            this.panel12.Controls.Add(this.label41);
            this.panel12.Controls.Add(this.guna2Separator7);
            this.panel12.Controls.Add(this.label42);
            this.panel12.Controls.Add(this.label43);
            this.panel12.Controls.Add(this.guna2GradientButton16);
            this.panel12.Controls.Add(this.guna2GradientButton17);
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Location = new System.Drawing.Point(4, 1364);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(445, 672);
            this.panel12.TabIndex = 26;
            // 
            // guna2GradientButton9
            // 
            this.guna2GradientButton9.Animated = true;
            this.guna2GradientButton9.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton9.CheckedState.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton9.CustomImages.Image")));
            this.guna2GradientButton9.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton9.CustomImages.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton9.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton9.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton9.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton9.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton9.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton9.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton9.HoverState.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Location = new System.Drawing.Point(212, 584);
            this.guna2GradientButton9.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton9.Name = "guna2GradientButton9";
            this.guna2GradientButton9.ShadowDecoration.Parent = this.guna2GradientButton9;
            this.guna2GradientButton9.Size = new System.Drawing.Size(188, 64);
            this.guna2GradientButton9.TabIndex = 23;
            this.guna2GradientButton9.Text = "Add to Bill";
            this.guna2GradientButton9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton9.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton9.UseTransparentBackground = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(61, 619);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(63, 23);
            this.label41.TabIndex = 22;
            this.label41.Text = "Rs 200";
            // 
            // guna2Separator7
            // 
            this.guna2Separator7.Location = new System.Drawing.Point(35, 559);
            this.guna2Separator7.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Separator7.Name = "guna2Separator7";
            this.guna2Separator7.Size = new System.Drawing.Size(381, 12);
            this.guna2Separator7.TabIndex = 20;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(43, 567);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(99, 46);
            this.label42.TabIndex = 19;
            this.label42.Text = "Price";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(63, 513);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(35, 20);
            this.label43.TabIndex = 18;
            this.label43.Text = "size";
            // 
            // guna2GradientButton16
            // 
            this.guna2GradientButton16.Animated = true;
            this.guna2GradientButton16.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton16.CheckedState.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton16.CustomImages.Image")));
            this.guna2GradientButton16.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton16.CustomImages.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton16.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton16.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton16.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton16.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton16.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton16.HoverState.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Location = new System.Drawing.Point(180, 496);
            this.guna2GradientButton16.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton16.Name = "guna2GradientButton16";
            this.guna2GradientButton16.ShadowDecoration.Parent = this.guna2GradientButton16;
            this.guna2GradientButton16.Size = new System.Drawing.Size(115, 55);
            this.guna2GradientButton16.TabIndex = 17;
            this.guna2GradientButton16.Text = "Medium";
            this.guna2GradientButton16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.guna2GradientButton16.TextOffset = new System.Drawing.Point(10, 0);
            this.guna2GradientButton16.UseTransparentBackground = true;
            // 
            // guna2GradientButton17
            // 
            this.guna2GradientButton17.Animated = true;
            this.guna2GradientButton17.BackColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton17.CheckedState.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("guna2GradientButton17.CustomImages.Image")));
            this.guna2GradientButton17.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2GradientButton17.CustomImages.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.FillColor = System.Drawing.Color.Empty;
            this.guna2GradientButton17.FillColor2 = System.Drawing.Color.Empty;
            this.guna2GradientButton17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton17.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton17.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2GradientButton17.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2GradientButton17.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GradientButton17.HoverState.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Location = new System.Drawing.Point(296, 496);
            this.guna2GradientButton17.Margin = new System.Windows.Forms.Padding(4);
            this.guna2GradientButton17.Name = "guna2GradientButton17";
            this.guna2GradientButton17.ShadowDecoration.Parent = this.guna2GradientButton17;
            this.guna2GradientButton17.Size = new System.Drawing.Size(140, 55);
            this.guna2GradientButton17.TabIndex = 16;
            this.guna2GradientButton17.Text = "Large";
            this.guna2GradientButton17.UseTransparentBackground = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.coffeeform.SetFlowBreak(this.label50, true);
            this.label50.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(457, 1360);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(99, 46);
            this.label50.TabIndex = 19;
            this.label50.Text = "Price";
            // 
            // Cappuccino_panel
            // 
            this.Cappuccino_panel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Cappuccino_panel.BackgroundImage")));
            this.Cappuccino_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.Cappuccino_panel.Controls.Add(this.tital_panal_cappuccino);
            this.Cappuccino_panel.Location = new System.Drawing.Point(20, 15);
            this.Cappuccino_panel.Margin = new System.Windows.Forms.Padding(4);
            this.Cappuccino_panel.Name = "Cappuccino_panel";
            this.Cappuccino_panel.Size = new System.Drawing.Size(400, 441);
            this.Cappuccino_panel.TabIndex = 0;
            // 
            // tital_panal_cappuccino
            // 
            this.tital_panal_cappuccino.BackColor = System.Drawing.Color.Transparent;
            this.tital_panal_cappuccino.Controls.Add(this.label11);
            this.tital_panal_cappuccino.Controls.Add(this.label10);
            this.tital_panal_cappuccino.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tital_panal_cappuccino.FillColor = System.Drawing.Color.Transparent;
            this.tital_panal_cappuccino.FillColor2 = System.Drawing.Color.Transparent;
            this.tital_panal_cappuccino.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.tital_panal_cappuccino.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.tital_panal_cappuccino.Location = new System.Drawing.Point(0, 300);
            this.tital_panal_cappuccino.Margin = new System.Windows.Forms.Padding(4);
            this.tital_panal_cappuccino.Name = "tital_panal_cappuccino";
            this.tital_panal_cappuccino.ShadowDecoration.Parent = this.tital_panal_cappuccino;
            this.tital_panal_cappuccino.Size = new System.Drawing.Size(400, 141);
            this.tital_panal_cappuccino.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(25, 71);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(355, 70);
            this.label11.TabIndex = 20;
            this.label11.Text = "a hot, frothy drink with a creamy top, milky middle, and full-bodied brew at the " +
    "bottom";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(25, 22);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(245, 49);
            this.label10.TabIndex = 19;
            this.label10.Text = "Cappuccino";
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel7.Controls.Add(this.guna2CustomGradientPanel2);
            this.panel7.Location = new System.Drawing.Point(20, 15);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(400, 441);
            this.panel7.TabIndex = 0;
            // 
            // guna2CustomGradientPanel2
            // 
            this.guna2CustomGradientPanel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.Controls.Add(this.label1);
            this.guna2CustomGradientPanel2.Controls.Add(this.label24);
            this.guna2CustomGradientPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel2.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel2.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel2.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel2.Location = new System.Drawing.Point(0, 311);
            this.guna2CustomGradientPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            this.guna2CustomGradientPanel2.ShadowDecoration.Parent = this.guna2CustomGradientPanel2;
            this.guna2CustomGradientPanel2.Size = new System.Drawing.Size(400, 130);
            this.guna2CustomGradientPanel2.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(25, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(355, 41);
            this.label1.TabIndex = 21;
            this.label1.Text = "a chocolate-flavoured warm beverage that is a variant of a café latte";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(30, 11);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(245, 49);
            this.label24.TabIndex = 19;
            this.label24.Text = "Mocha Latte";
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.Controls.Add(this.guna2CustomGradientPanel3);
            this.panel9.Location = new System.Drawing.Point(20, 15);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(400, 441);
            this.panel9.TabIndex = 0;
            // 
            // guna2CustomGradientPanel3
            // 
            this.guna2CustomGradientPanel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel3.Controls.Add(this.label2);
            this.guna2CustomGradientPanel3.Controls.Add(this.label32);
            this.guna2CustomGradientPanel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel3.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel3.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel3.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel3.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel3.Location = new System.Drawing.Point(0, 311);
            this.guna2CustomGradientPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CustomGradientPanel3.Name = "guna2CustomGradientPanel3";
            this.guna2CustomGradientPanel3.ShadowDecoration.Parent = this.guna2CustomGradientPanel3;
            this.guna2CustomGradientPanel3.Size = new System.Drawing.Size(400, 130);
            this.guna2CustomGradientPanel3.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(4, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(355, 41);
            this.label2.TabIndex = 22;
            this.label2.Text = "a shot or two of bold, tasty espresso with fresh, sweet steamed milk over it";
            // 
            // label32
            // 
            this.label32.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(25, 22);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(245, 49);
            this.label32.TabIndex = 19;
            this.label32.Text = "Cafe Latte";
            // 
            // panel11
            // 
            this.panel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel11.BackgroundImage")));
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel11.Controls.Add(this.guna2CustomGradientPanel4);
            this.panel11.Location = new System.Drawing.Point(20, 15);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(400, 441);
            this.panel11.TabIndex = 0;
            // 
            // guna2CustomGradientPanel4
            // 
            this.guna2CustomGradientPanel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel4.Controls.Add(this.label3);
            this.guna2CustomGradientPanel4.Controls.Add(this.label40);
            this.guna2CustomGradientPanel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel4.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel4.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel4.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel4.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel4.Location = new System.Drawing.Point(0, 311);
            this.guna2CustomGradientPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CustomGradientPanel4.Name = "guna2CustomGradientPanel4";
            this.guna2CustomGradientPanel4.ShadowDecoration.Parent = this.guna2CustomGradientPanel4;
            this.guna2CustomGradientPanel4.Size = new System.Drawing.Size(400, 130);
            this.guna2CustomGradientPanel4.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(16, 71);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(355, 41);
            this.label3.TabIndex = 23;
            this.label3.Text = "a coffee drink that contains espresso coffee, steamed and frothed milk, and caram" +
    "el sauce";
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(25, 22);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(245, 49);
            this.label40.TabIndex = 19;
            this.label40.Text = "Caramel Latte";
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel13.Controls.Add(this.guna2CustomGradientPanel5);
            this.panel13.Location = new System.Drawing.Point(20, 15);
            this.panel13.Margin = new System.Windows.Forms.Padding(4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(400, 441);
            this.panel13.TabIndex = 0;
            // 
            // guna2CustomGradientPanel5
            // 
            this.guna2CustomGradientPanel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel5.Controls.Add(this.label4);
            this.guna2CustomGradientPanel5.Controls.Add(this.label48);
            this.guna2CustomGradientPanel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2CustomGradientPanel5.FillColor = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel5.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2CustomGradientPanel5.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel5.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel5.Location = new System.Drawing.Point(0, 311);
            this.guna2CustomGradientPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.guna2CustomGradientPanel5.Name = "guna2CustomGradientPanel5";
            this.guna2CustomGradientPanel5.ShadowDecoration.Parent = this.guna2CustomGradientPanel5;
            this.guna2CustomGradientPanel5.Size = new System.Drawing.Size(400, 130);
            this.guna2CustomGradientPanel5.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(25, 71);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(355, 41);
            this.label4.TabIndex = 24;
            this.label4.Text = "a coffee drink that contains espresso coffee, steamed and frothed milk, and caram" +
    "el sauce";
            // 
            // label48
            // 
            this.label48.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(25, 22);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(371, 49);
            this.label48.TabIndex = 19;
            this.label48.Text = "Iced Americano";
            // 
            // coffee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.coffeeform);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "coffee";
            this.Text = "coffee";
            this.coffeeform.ResumeLayout(false);
            this.coffeeform.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.Cappuccino_panel.ResumeLayout(false);
            this.tital_panal_cappuccino.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.guna2CustomGradientPanel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.guna2CustomGradientPanel3.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.guna2CustomGradientPanel4.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.guna2CustomGradientPanel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel coffeeform;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label17;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton5;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private System.Windows.Forms.Panel Cappuccino_panel;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel tital_panal_cappuccino;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton7;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton8;
        private System.Windows.Forms.Panel panel7;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label25;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton10;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton11;
        private System.Windows.Forms.Panel panel9;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel3;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label33;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator6;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton13;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton14;
        private System.Windows.Forms.Panel panel11;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label41;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator7;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton16;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton17;
        private System.Windows.Forms.Panel panel13;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel5;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton6;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton9;
        private System.Windows.Forms.Label label4;
    }
}