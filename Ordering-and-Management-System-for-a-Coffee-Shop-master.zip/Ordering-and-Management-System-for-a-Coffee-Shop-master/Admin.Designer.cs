﻿
namespace user_interface
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            Guna.UI2.AnimatorNS.Animation animation3 = new Guna.UI2.AnimatorNS.Animation();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2Separator2 = new Guna.UI2.WinForms.Guna2Separator();
            this.guna2VSeparator1 = new Guna.UI2.WinForms.Guna2VSeparator();
            this.btn_show = new Guna.UI2.WinForms.Guna2CircleButton();
            this.btn_hide = new Guna.UI2.WinForms.Guna2CircleButton();
            this.guna2Separator1 = new Guna.UI2.WinForms.Guna2Separator();
            this.btn_logout = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Settings = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Lasagna = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Savouries = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btn_Pizza = new Guna.UI2.WinForms.Guna2GradientButton();
            this.Btn_food = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btm = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.txt_timer = new System.Windows.Forms.Label();
            this.adminTransition = new Guna.UI2.WinForms.Guna2Transition();
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).BeginInit();
            this.guna2CustomGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BackColor = System.Drawing.Color.Black;
            this.guna2Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.guna2Panel1.Controls.Add(this.guna2CirclePictureBox2);
            this.guna2Panel1.Controls.Add(this.guna2Separator2);
            this.guna2Panel1.Controls.Add(this.guna2VSeparator1);
            this.guna2Panel1.Controls.Add(this.btn_show);
            this.guna2Panel1.Controls.Add(this.btn_hide);
            this.guna2Panel1.Controls.Add(this.guna2Separator1);
            this.guna2Panel1.Controls.Add(this.btn_logout);
            this.guna2Panel1.Controls.Add(this.btn_Settings);
            this.guna2Panel1.Controls.Add(this.btn_Lasagna);
            this.guna2Panel1.Controls.Add(this.btn_Savouries);
            this.guna2Panel1.Controls.Add(this.btn_Pizza);
            this.guna2Panel1.Controls.Add(this.Btn_food);
            this.guna2Panel1.Controls.Add(this.btm);
            this.adminTransition.SetDecoration(this.guna2Panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(204, 533);
            this.guna2Panel1.TabIndex = 2;
            // 
            // guna2CirclePictureBox2
            // 
            this.adminTransition.SetDecoration(this.guna2CirclePictureBox2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox2.Image")));
            this.guna2CirclePictureBox2.Location = new System.Drawing.Point(42, 3);
            this.guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            this.guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox2.ShadowDecoration.Parent = this.guna2CirclePictureBox2;
            this.guna2CirclePictureBox2.Size = new System.Drawing.Size(111, 115);
            this.guna2CirclePictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox2.TabIndex = 17;
            this.guna2CirclePictureBox2.TabStop = false;
            // 
            // guna2Separator2
            // 
            this.adminTransition.SetDecoration(this.guna2Separator2, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.guna2Separator2.Location = new System.Drawing.Point(3, 372);
            this.guna2Separator2.Name = "guna2Separator2";
            this.guna2Separator2.Size = new System.Drawing.Size(192, 15);
            this.guna2Separator2.TabIndex = 16;
            // 
            // guna2VSeparator1
            // 
            this.guna2VSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.adminTransition.SetDecoration(this.guna2VSeparator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2VSeparator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.guna2VSeparator1.Location = new System.Drawing.Point(3, 126);
            this.guna2VSeparator1.Name = "guna2VSeparator1";
            this.guna2VSeparator1.Size = new System.Drawing.Size(10, 49);
            this.guna2VSeparator1.TabIndex = 4;
            // 
            // btn_show
            // 
            this.btn_show.Animated = true;
            this.btn_show.BorderColor = System.Drawing.Color.Transparent;
            this.btn_show.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_show.CheckedState.Parent = this.btn_show;
            this.btn_show.CustomImages.Parent = this.btn_show;
            this.adminTransition.SetDecoration(this.btn_show, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_show.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.btn_show.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_show.ForeColor = System.Drawing.Color.White;
            this.btn_show.HoverState.Parent = this.btn_show;
            this.btn_show.Image = ((System.Drawing.Image)(resources.GetObject("btn_show.Image")));
            this.btn_show.Location = new System.Drawing.Point(6, 464);
            this.btn_show.Name = "btn_show";
            this.btn_show.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btn_show.ShadowDecoration.Parent = this.btn_show;
            this.btn_show.Size = new System.Drawing.Size(40, 40);
            this.btn_show.TabIndex = 15;
            this.btn_show.Visible = false;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.Animated = true;
            this.btn_hide.BorderColor = System.Drawing.Color.Transparent;
            this.btn_hide.ButtonMode = Guna.UI2.WinForms.Enums.ButtonMode.RadioButton;
            this.btn_hide.CheckedState.Parent = this.btn_hide;
            this.btn_hide.CustomImages.Parent = this.btn_hide;
            this.adminTransition.SetDecoration(this.btn_hide, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_hide.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(63)))), ((int)(((byte)(81)))));
            this.btn_hide.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btn_hide.ForeColor = System.Drawing.Color.White;
            this.btn_hide.HoverState.Parent = this.btn_hide;
            this.btn_hide.Image = ((System.Drawing.Image)(resources.GetObject("btn_hide.Image")));
            this.btn_hide.Location = new System.Drawing.Point(179, 464);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.btn_hide.ShadowDecoration.Parent = this.btn_hide;
            this.btn_hide.Size = new System.Drawing.Size(40, 40);
            this.btn_hide.TabIndex = 2;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // guna2Separator1
            // 
            this.adminTransition.SetDecoration(this.guna2Separator1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2Separator1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.guna2Separator1.Location = new System.Drawing.Point(12, 477);
            this.guna2Separator1.Name = "guna2Separator1";
            this.guna2Separator1.Size = new System.Drawing.Size(192, 15);
            this.guna2Separator1.TabIndex = 14;
            // 
            // btn_logout
            // 
            this.btn_logout.Animated = true;
            this.btn_logout.BackColor = System.Drawing.Color.Transparent;
            this.btn_logout.CheckedState.Parent = this.btn_logout;
            this.btn_logout.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_logout.CustomImages.Image")));
            this.btn_logout.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_logout.CustomImages.Parent = this.btn_logout;
            this.adminTransition.SetDecoration(this.btn_logout, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_logout.FillColor = System.Drawing.Color.Empty;
            this.btn_logout.FillColor2 = System.Drawing.Color.Empty;
            this.btn_logout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_logout.ForeColor = System.Drawing.Color.White;
            this.btn_logout.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_logout.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_logout.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_logout.HoverState.Parent = this.btn_logout;
            this.btn_logout.Location = new System.Drawing.Point(3, 510);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.ShadowDecoration.Parent = this.btn_logout;
            this.btn_logout.Size = new System.Drawing.Size(195, 45);
            this.btn_logout.TabIndex = 13;
            this.btn_logout.Text = "Log Out";
            this.btn_logout.UseTransparentBackground = true;
            // 
            // btn_Settings
            // 
            this.btn_Settings.Animated = true;
            this.btn_Settings.BackColor = System.Drawing.Color.Transparent;
            this.btn_Settings.CheckedState.Parent = this.btn_Settings;
            this.btn_Settings.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Settings.CustomImages.Image")));
            this.btn_Settings.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Settings.CustomImages.Parent = this.btn_Settings;
            this.adminTransition.SetDecoration(this.btn_Settings, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Settings.FillColor = System.Drawing.Color.Empty;
            this.btn_Settings.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Settings.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Settings.ForeColor = System.Drawing.Color.White;
            this.btn_Settings.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Settings.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Settings.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Settings.HoverState.Parent = this.btn_Settings;
            this.btn_Settings.Location = new System.Drawing.Point(0, 404);
            this.btn_Settings.Name = "btn_Settings";
            this.btn_Settings.ShadowDecoration.Parent = this.btn_Settings;
            this.btn_Settings.Size = new System.Drawing.Size(195, 45);
            this.btn_Settings.TabIndex = 12;
            this.btn_Settings.Text = "Settings";
            this.btn_Settings.UseTransparentBackground = true;
            // 
            // btn_Lasagna
            // 
            this.btn_Lasagna.Animated = true;
            this.btn_Lasagna.BackColor = System.Drawing.Color.Transparent;
            this.btn_Lasagna.CheckedState.Parent = this.btn_Lasagna;
            this.btn_Lasagna.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Lasagna.CustomImages.Image")));
            this.btn_Lasagna.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Lasagna.CustomImages.Parent = this.btn_Lasagna;
            this.adminTransition.SetDecoration(this.btn_Lasagna, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Lasagna.FillColor = System.Drawing.Color.Empty;
            this.btn_Lasagna.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Lasagna.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Lasagna.ForeColor = System.Drawing.Color.White;
            this.btn_Lasagna.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Lasagna.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Lasagna.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Lasagna.HoverState.Parent = this.btn_Lasagna;
            this.btn_Lasagna.Location = new System.Drawing.Point(0, 321);
            this.btn_Lasagna.Name = "btn_Lasagna";
            this.btn_Lasagna.ShadowDecoration.Parent = this.btn_Lasagna;
            this.btn_Lasagna.Size = new System.Drawing.Size(195, 45);
            this.btn_Lasagna.TabIndex = 11;
            this.btn_Lasagna.Text = "Change Password";
            this.btn_Lasagna.UseTransparentBackground = true;
            // 
            // btn_Savouries
            // 
            this.btn_Savouries.Animated = true;
            this.btn_Savouries.BackColor = System.Drawing.Color.Transparent;
            this.btn_Savouries.CheckedState.Parent = this.btn_Savouries;
            this.btn_Savouries.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Savouries.CustomImages.Image")));
            this.btn_Savouries.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Savouries.CustomImages.Parent = this.btn_Savouries;
            this.adminTransition.SetDecoration(this.btn_Savouries, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Savouries.FillColor = System.Drawing.Color.Empty;
            this.btn_Savouries.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Savouries.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Savouries.ForeColor = System.Drawing.Color.White;
            this.btn_Savouries.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Savouries.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Savouries.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Savouries.HoverState.Parent = this.btn_Savouries;
            this.btn_Savouries.Location = new System.Drawing.Point(3, 270);
            this.btn_Savouries.Name = "btn_Savouries";
            this.btn_Savouries.ShadowDecoration.Parent = this.btn_Savouries;
            this.btn_Savouries.Size = new System.Drawing.Size(195, 45);
            this.btn_Savouries.TabIndex = 9;
            this.btn_Savouries.Text = "Add Employee";
            this.btn_Savouries.UseTransparentBackground = true;
            // 
            // btn_Pizza
            // 
            this.btn_Pizza.Animated = true;
            this.btn_Pizza.BackColor = System.Drawing.Color.Transparent;
            this.btn_Pizza.CheckedState.Parent = this.btn_Pizza;
            this.btn_Pizza.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_Pizza.CustomImages.Image")));
            this.btn_Pizza.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btn_Pizza.CustomImages.Parent = this.btn_Pizza;
            this.adminTransition.SetDecoration(this.btn_Pizza, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btn_Pizza.FillColor = System.Drawing.Color.Empty;
            this.btn_Pizza.FillColor2 = System.Drawing.Color.Empty;
            this.btn_Pizza.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btn_Pizza.ForeColor = System.Drawing.Color.White;
            this.btn_Pizza.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btn_Pizza.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btn_Pizza.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.btn_Pizza.HoverState.Parent = this.btn_Pizza;
            this.btn_Pizza.Location = new System.Drawing.Point(0, 219);
            this.btn_Pizza.Name = "btn_Pizza";
            this.btn_Pizza.ShadowDecoration.Parent = this.btn_Pizza;
            this.btn_Pizza.Size = new System.Drawing.Size(195, 45);
            this.btn_Pizza.TabIndex = 8;
            this.btn_Pizza.Text = "Report";
            this.btn_Pizza.UseTransparentBackground = true;
            // 
            // Btn_food
            // 
            this.Btn_food.Animated = true;
            this.Btn_food.BackColor = System.Drawing.Color.Transparent;
            this.Btn_food.CheckedState.Parent = this.Btn_food;
            this.Btn_food.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("Btn_food.CustomImages.Image")));
            this.Btn_food.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Btn_food.CustomImages.Parent = this.Btn_food;
            this.adminTransition.SetDecoration(this.Btn_food, Guna.UI2.AnimatorNS.DecorationType.None);
            this.Btn_food.FillColor = System.Drawing.Color.Empty;
            this.Btn_food.FillColor2 = System.Drawing.Color.Empty;
            this.Btn_food.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Btn_food.ForeColor = System.Drawing.Color.White;
            this.Btn_food.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.Btn_food.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.Btn_food.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.Btn_food.HoverState.Parent = this.Btn_food;
            this.Btn_food.Location = new System.Drawing.Point(-2, 181);
            this.Btn_food.Name = "Btn_food";
            this.Btn_food.ShadowDecoration.Parent = this.Btn_food;
            this.Btn_food.Size = new System.Drawing.Size(195, 45);
            this.Btn_food.TabIndex = 7;
            this.Btn_food.Text = "Daily Sales";
            this.Btn_food.UseTransparentBackground = true;
            // 
            // btm
            // 
            this.btm.Animated = true;
            this.btm.BackColor = System.Drawing.Color.Transparent;
            this.btm.CheckedState.Parent = this.btm;
            this.btm.CustomImages.Image = ((System.Drawing.Image)(resources.GetObject("btn_cofee.CustomImages.Image")));
            this.btm.CustomImages.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btm.CustomImages.Parent = this.btm;
            this.adminTransition.SetDecoration(this.btm, Guna.UI2.AnimatorNS.DecorationType.None);
            this.btm.FillColor = System.Drawing.Color.Empty;
            this.btm.FillColor2 = System.Drawing.Color.Empty;
            this.btm.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btm.ForeColor = System.Drawing.Color.White;
            this.btm.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(64)))), ((int)(((byte)(7)))));
            this.btm.HoverState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(52)))));
            this.btm.HoverState.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btm.HoverState.Parent = this.btm;
            this.btm.Location = new System.Drawing.Point(3, 130);
            this.btm.Name = "btm";
            this.btm.ShadowDecoration.Parent = this.btm;
            this.btm.Size = new System.Drawing.Size(195, 45);
            this.btm.TabIndex = 6;
            this.btm.Text = "Add Items";
            this.btm.UseTransparentBackground = true;
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.Controls.Add(this.txt_timer);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2CirclePictureBox1);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2ControlBox1);
            this.adminTransition.SetDecoration(this.guna2CustomGradientPanel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CustomGradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.Color.Black;
            this.guna2CustomGradientPanel1.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(140)))), ((int)(((byte)(52)))));
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(204, 0);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.ShadowDecoration.Parent = this.guna2CustomGradientPanel1;
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(719, 75);
            this.guna2CustomGradientPanel1.TabIndex = 13;
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.adminTransition.SetDecoration(this.guna2CirclePictureBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2CirclePictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("guna2CirclePictureBox1.Image")));
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(609, 3);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.ShadowDecoration.Parent = this.guna2CirclePictureBox1;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(64, 64);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.guna2CirclePictureBox1.TabIndex = 17;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(86)))), ((int)(((byte)(53)))));
            this.adminTransition.SetDecoration(this.guna2ControlBox1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.guna2ControlBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2ControlBox1.HoverState.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.Location = new System.Drawing.Point(670, 12);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.ShadowDecoration.Parent = this.guna2ControlBox1;
            this.guna2ControlBox1.Size = new System.Drawing.Size(37, 26);
            this.guna2ControlBox1.TabIndex = 1;
            // 
            // txt_timer
            // 
            this.txt_timer.AutoSize = true;
            this.txt_timer.BackColor = System.Drawing.Color.Transparent;
            this.adminTransition.SetDecoration(this.txt_timer, Guna.UI2.AnimatorNS.DecorationType.None);
            this.txt_timer.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold);
            this.txt_timer.ForeColor = System.Drawing.Color.White;
            this.txt_timer.Location = new System.Drawing.Point(6, 21);
            this.txt_timer.Name = "txt_timer";
            this.txt_timer.Size = new System.Drawing.Size(183, 54);
            this.txt_timer.TabIndex = 43;
            this.txt_timer.Text = "00.00.00";
            this.txt_timer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // adminTransition
            // 
            this.adminTransition.AnimationType = Guna.UI2.AnimatorNS.AnimationType.Rotate;
            this.adminTransition.Cursor = null;
            animation3.AnimateOnlyDifferences = true;
            animation3.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.BlindCoeff")));
            animation3.LeafCoeff = 0F;
            animation3.MaxTime = 1F;
            animation3.MinTime = 0F;
            animation3.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicCoeff")));
            animation3.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicShift")));
            animation3.MosaicSize = 0;
            animation3.Padding = new System.Windows.Forms.Padding(50);
            animation3.RotateCoeff = 1F;
            animation3.RotateLimit = 0F;
            animation3.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.ScaleCoeff")));
            animation3.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.SlideCoeff")));
            animation3.TimeCoeff = 0F;
            animation3.TransparencyCoeff = 1F;
            this.adminTransition.DefaultAnimation = animation3;
            // 
            // panel1
            // 
            this.adminTransition.SetDecoration(this.panel1, Guna.UI2.AnimatorNS.DecorationType.None);
            this.panel1.Location = new System.Drawing.Point(204, 73);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(719, 460);
            this.panel1.TabIndex = 14;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(923, 533);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.Controls.Add(this.guna2Panel1);
            this.adminTransition.SetDecoration(this, Guna.UI2.AnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin";
            this.Text = "Admin";
            this.guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox2)).EndInit();
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.guna2CustomGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator2;
        private Guna.UI2.WinForms.Guna2VSeparator guna2VSeparator1;
        private Guna.UI2.WinForms.Guna2CircleButton btn_show;
        private Guna.UI2.WinForms.Guna2CircleButton btn_hide;
        private Guna.UI2.WinForms.Guna2Separator guna2Separator1;
        private Guna.UI2.WinForms.Guna2GradientButton btn_logout;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Settings;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Lasagna;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Savouries;
        private Guna.UI2.WinForms.Guna2GradientButton btn_Pizza;
        private Guna.UI2.WinForms.Guna2GradientButton Btn_food;
        private Guna.UI2.WinForms.Guna2GradientButton btm;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private System.Windows.Forms.Label txt_timer;
        private Guna.UI2.WinForms.Guna2Transition adminTransition;
        private System.Windows.Forms.Panel panel1;
    }
}